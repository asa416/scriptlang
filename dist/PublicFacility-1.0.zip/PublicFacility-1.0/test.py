from tkinter import *
import tkinter.font

window = Tk()

print(list(tkinter.font.families()))