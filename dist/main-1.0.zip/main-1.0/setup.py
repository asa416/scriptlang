from distutils.core import setup, Extension

module_rect = Extension('rect', sources=['rectmodule.cpp'])

setup(
    name='main',
    version='1.0',

    py_modules=['data', 'imaga', 'main', 'mapview', 'send_email'],

    packages=['images'],
    package_data={'images':['*.png']},

    ext_modules=[module_rect],
)